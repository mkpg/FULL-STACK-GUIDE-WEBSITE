// Main constants index file
// This file exports all workshop sections from their individual files

export { SECTIONS } from './sections';
export { WORKSHOP_CONFIG } from './config';
